
def Print_welcome():
    """This function will print Welcome message"""
    
    HANGMAN_ASCII_ART = ("""Welcome to the Hangman game \n
  _    _                                         
 | |  | |                                        
 | |__| | __ _ _ __   __ _ _ __ ___   __ _ _ __  
 |  __  |/ _` | '_ \ / _` | '_ ` _ \ / _` | '_ \ 
 | |  | | (_| | | | | (_| | | | | | | (_| | | | |
 |_|  |_|\__,_|_| |_|\__, |_| |_| |_|\__,_|_| |_|
                      __/ |                      
                     |___/ \n""")

    print(HANGMAN_ASCII_ART , MAX_TRIES)

state0 = """    x-------x"""

state1 = """    x-------x
    |
    |
    |
    |
    |
"""

state2 = """    x-------x
    |       |
    |       0
    |
    |
    |
"""

state3 = """    x-------x
    |       |
    |       0
    |       |
    |
    |
"""

state4 = """    x-------x
    |       |
    |       0
    |      /|\\
    |
    |
"""

state5 = """    x-------x
    |       |
    |       0
    |      /|\\
    |      /
    |
"""

state6 = """    x-------x
    |       |
    |       0
    |      /|\\
    |      / \\
    |"""
	

HANGMAN_PHOTOS = {1: state0, 2: state1, 3: state2, 4: state3, 5: state4, 6: state5, 7: state6}

MAX_TRIES = 6

def print_hangman(num_of_tries):
    print(HANGMAN_PHOTOS[num_of_tries])

def check_win(secret_word, old_letters_guessed):
    """This function will check if the player has won the game.
    :param secret_word: The word to guess.
    :param old_letters_guessed: letters guessed so far.
    :type secret_word: string.
    :type old_letters_guessed: list.
    :return: has the player won or not.
    :rtype: bool.
    """
   
    check = True
    for letter in secret_word:
        if letter not in old_letters_guessed:
            check = False
    return check
        
def show_hidden_word(secret_word, old_letters_guessed):
    """This function will present to the player the progress of his guessing.
    :param secret_word: The word to guess.
    :param old_letters_guessed: letters guessed so far.
    :type secret_word: string.
    :type old_letters_guessed: list.
    :return: the letters guessed correctly embedd in the word.
    :rtype: string.
    """
    guess = ""
    for letter in secret_word:
        if letter in old_letters_guessed:
            guess += letter + " "
        else:
            guess += "_ "
    return guess[ : -1]
        
def check_valid_input(letter_guessed, old_letters_guessed):
    """This function declairs if the guessed letter is valid and if 
    it was already guessed before.
    :param letter_guessed: the new guess.
    :type letter_guessed: string
    :param old_letters_guessed: letters guessed so far.
    :type old_letters_guessed: list.
    :return: is the guess valid.
    :rtype: bool.
    """
    
    if not letter_guessed.isalpha():
        return False
    elif len(letter_guessed) > 1:
        return False
    elif letter_guessed.lower()  in old_letters_guessed:
        return False
    else:
        return True
        
def try_update_letter_guessed(letter_guessed, old_letters_guessed):
    """This function updates the guessed letters list in case the new guess is valid.
    :param letter_guessed: the new guess.
    :type letter_guessed: string
    :param old_letters_guessed: letters guessed so far.
    :type old_letters_guessed: list.
    :return: is the guess added successfuly,.
    :rtype: bool.
    """
    
    if check_valid_input(letter_guessed, old_letters_guessed):
        old_letters_guessed += letter_guessed.lower()
        old_letters_guessed += letter_guessed.upper()
        return True
    else:
        print("\nX\n", " -> ".join(sorted(list({x.lower() for x in old_letters_guessed}), key= str.lower)))
        return False
        
def choose_word(file_path, index):
    """This function will chhose a word to be guessed out of a given file.
    :param file_path: the path to the word file.
    :param index: index for chosen word.
    :type file_path: string.
    :type index: int.
    :return: number of repeatative words and chosen word.
    :rtype: tuple.
    """
    f = open(file_path, "r")
    words = f.read().split(" ")
    f.close()
    return len(set(words)), words[index % len(words) - 1]
    
def Hangman():
    """This function will launch the Hangman game.
    :return: None.
    """
    
    Print_welcome()
    file_path = input("Enter file path: ") #Enter path to file with word posibilities.
    index = int(input("Enter Index: "))  # Enter index of chosen word in the word file.
    
    secret_word = choose_word(file_path, index)[1]
    old_letters_guessed = []
    num_of_tries = 1
    
    print("\nLet's start!\n")
    print_hangman(num_of_tries)
    print("\n\n", show_hidden_word(secret_word, old_letters_guessed), "\n")
    
    while not check_win(secret_word, old_letters_guessed):
        letter_guessed = input("\nGuess a letter: ").lower()
        while not try_update_letter_guessed(letter_guessed, old_letters_guessed):
            letter_guessed = input("\nGuess a letter: ")
        if letter_guessed.lower() in secret_word or letter_guessed.upper() in secret_word:
            print("\n", show_hidden_word(secret_word, old_letters_guessed), "\n")
        else:
            print("\n:(\n")
            num_of_tries += 1
            print_hangman(num_of_tries)
            print("\n", show_hidden_word(secret_word, old_letters_guessed), "\n")            
        if num_of_tries == MAX_TRIES + 1:
            print("\nLOSE")
            old_letters_guessed += list(secret_word)
            print("\n", show_hidden_word(secret_word, old_letters_guessed), "\n")
            return
    print("\nWIN")
    
def main():
    Hangman()

if __name__ == "__main__":
    main()